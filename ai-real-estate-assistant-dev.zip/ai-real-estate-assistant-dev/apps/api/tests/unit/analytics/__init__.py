"""Tests for analytics modules."""
