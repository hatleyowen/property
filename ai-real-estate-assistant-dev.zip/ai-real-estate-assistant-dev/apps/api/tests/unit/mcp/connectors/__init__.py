"""Tests for MCP connectors."""
