"""Tests for enrichment package."""
