"""
Rules package initializer.
"""
